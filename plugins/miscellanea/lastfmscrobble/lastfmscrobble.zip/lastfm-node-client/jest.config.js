module.exports = {
	verbose: true,
	testMatch: [
		"**/test/**/*.[jt]s?(x)",
		"**/?(*.)+(spec|test).[jt]s?(x)"
	]
};
